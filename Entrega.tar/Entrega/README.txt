HOLA :)

Soy Juan Arquero del CIT41 y en este fichero presento los ejercicios del seminario ADA para STR

	Ejercicio 1 -> bucles.adb
	Ejercicios 2 y 3 -> agua_recogida.adb
	Ejercicio4 -> lanzatareas.adb
	Ejercicio5 -> ejercicio5.adb
	Ejercicio6a -> vectoroperations.adb (Paquete), vectoroperations.ads (Cabeceras de paquete) y ejercicio6.adb (Procedure que hace uso del paquete)
	Ejercicio6b ->  vectorprotegido.adb y vectorprotegido.ads (Paquete con objeto protegido)
			vectorprotegidotasks.adb y vectorprotegidotasks.ads (Paquete con tareas)
			ejercicio6b.adb (Programa que llama al paquete con tareas para empezar ejecución)